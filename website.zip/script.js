// 화면 전환 함수
function showScreen(id) {
  document.querySelectorAll('main > div').forEach(div => {
    if (div.id === id) div.classList.remove('hidden');
    else div.classList.add('hidden');
  });
}
// 홈 화면 버튼들
const btnDday = document.getElementById('btnDday');
const btnInterval = document.getElementById('btnInterval');
const btnTextToImage = document.getElementById('btnTextToImage');
const btnTextFile = document.getElementById('btnTextFile');
// D-Day 화면 요소
const ddayClose = document.getElementById('ddayClose');
const ddayYear = document.getElementById('ddayYear');
const ddayMonth = document.getElementById('ddayMonth');
const ddayDay = document.getElementById('ddayDay');
const ddayConfirm = document.getElementById('ddayConfirm');
const ddayReset = document.getElementById('ddayReset');
const ddayResult = document.getElementById('ddayResult');
// 날짜 간격 화면 요소
const intervalClose = document.getElementById('intervalClose');
const intYear1 = document.getElementById('intYear1');
const intMonth1 = document.getElementById('intMonth1');
const intDay1 = document.getElementById('intDay1');
const intYear2 = document.getElementById('intYear2');
const intMonth2 = document.getElementById('intMonth2');
const intDay2 = document.getElementById('intDay2');
const intervalConfirm = document.getElementById('intervalConfirm');
const intervalReset = document.getElementById('intervalReset');
const intervalResult = document.getElementById('intervalResult');
// 텍스트투이미지 화면 요소
const ttiClose = document.getElementById('ttiClose');
const ttiInput = document.getElementById('ttiInput');
const ttiConfirm = document.getElementById('ttiConfirm');
// 이미지 파일명 입력 화면 요소
const imageFileName = document.getElementById('imageFileName');
const imageFileExt = document.getElementById('imageFileExt');
const imageCancel = document.getElementById('imageCancel');
const imageSave = document.getElementById('imageSave');
// 텍스트 파일 만들기 화면 요소
const tfClose = document.getElementById('tfClose');
const tfInput = document.getElementById('tfInput');
const tfFileExt = document.getElementById('tfFileExt');
const tfCancel = document.getElementById('tfCancel');
const tfConfirm = document.getElementById('tfConfirm');
// 텍스트 파일명 입력 화면 요소
const textFileName = document.getElementById('textFileName');
const textFileCancel = document.getElementById('textFileCancel');
const textFileSave = document.getElementById('textFileSave');
// 푸터 버튼들
const userLinkBtn = document.getElementById('userLinkBtn');
const phoneBtn = document.getElementById('phoneBtn');
const emailBtn = document.getElementById('emailBtn');
// 홈 버튼 이벤트
btnDday.addEventListener('click', () => showScreen('ddayScreen'));
btnInterval.addEventListener('click', () => showScreen('intervalScreen'));
btnTextToImage.addEventListener('click', () => showScreen('textToImageScreen'));
btnTextFile.addEventListener('click', () => showScreen('textFileScreen'));
// 창 닫기 버튼 이벤트
ddayClose.addEventListener('click', () => showScreen('homeScreen'));
intervalClose.addEventListener('click', () => showScreen('homeScreen'));
ttiClose.addEventListener('click', () => showScreen('homeScreen'));
tfClose.addEventListener('click', () => showScreen('homeScreen'));
// 초기화 버튼 이벤트
ddayReset.addEventListener('click', () => {
  ddayYear.value = '';
  ddayMonth.value = '';
  ddayDay.value = '';
  ddayResult.textContent = '';
});
intervalReset.addEventListener('click', () => {
  intYear1.value = '';
  intMonth1.value = '';
  intDay1.value = '';
  intYear2.value = '';
  intMonth2.value = '';
  intDay2.value = '';
  intervalResult.textContent = '';
});
// D-Day 계산 확인 버튼
ddayConfirm.addEventListener('click', () => {
  const y = parseInt(ddayYear.value);
  const m = parseInt(ddayMonth.value);
  const d = parseInt(ddayDay.value);
  if (!y || !m || !d || m < 1 || m > 12 || d < 1 || d > 31) {
    ddayResult.textContent = '정확히 입력하세요.';
    return;
  }
  const target = new Date(y, m - 1, d);
  const now = new Date();
  const diffMs = target - now;
  const diffDays = Math.ceil(diffMs / (1000 * 60 * 60 * 24));
  ddayResult.textContent = `D-${diffDays}`;
});
// 날짜 간격 계산 확인 버튼
intervalConfirm.addEventListener('click', () => {
  const y1 = parseInt(intYear1.value);
  const m1 = parseInt(intMonth1.value);
  const d1 = parseInt(intDay1.value);
  const y2 = parseInt(intYear2.value);
  const m2 = parseInt(intMonth2.value);
  const d2 = parseInt(intDay2.value);
  if (
    !y1 || !m1 || !d1 || !y2 || !m2 || !d2 ||
    m1 < 1 || m1 > 12 || d1 < 1 || d1 > 31 ||
    m2 < 1 || m2 > 12 || d2 < 1 || d2 > 31
  ) {
    intervalResult.textContent = '정확히 입력하세요.';
    return;
  }
  const date1 = new Date(y1, m1 - 1, d1);
  const date2 = new Date(y2, m2 - 1, d2);
  const diffMs = Math.abs(date2 - date1);
  const diffDays = Math.ceil(diffMs / (1000 * 60 * 60 * 24));
  intervalResult.textContent = `${diffDays}일 간격입니다.`;
});
// 텍스트투이미지 확인 버튼
ttiConfirm.addEventListener('click', () => {
  if (!ttiInput.value.trim()) {
    alert('텍스트를 입력하세요.');
    return;
  }
  showScreen('imageNameScreen');
  imageFileName.value = '';
  imageSave.disabled = true;
});
// 이미지 파일명 입력 시
imageFileName.addEventListener('input', () => {
  imageSave.disabled = !imageFileName.value.trim();
});
// 이미지 파일 저장 버튼
imageSave.addEventListener('click', () => {
  const name = imageFileName.value.trim();
  const ext = imageFileExt.value;
  if (!name) return;
  createImageFile(ttiInput.value.trim(), name, ext);
  showScreen('homeScreen');
  ttiInput.value = '';
});
// 이미지 파일 생성 함수
function createImageFile(text, fileName, ext) {
  const canvas = document.createElement('canvas');
  canvas.width = 600;
  canvas.height = 200;
  const ctx = canvas.getContext('2d');
  ctx.fillStyle = '#ffffff';
  ctx.fillRect(0, 0, canvas.width, canvas.height);
  ctx.fillStyle = '#000000';
  ctx.font = '20px Arial';
  ctx.fillText(text, 20, 100);
  canvas.toBlob(blob => {
    const link = document.createElement('a');
    link.href = URL.createObjectURL(blob);
    link.download = `${fileName}.${ext}`;
    document.body.appendChild(link);
    link.click();
    link.remove();
  }, `image/${ext}`);
}
// 텍스트 파일 만들기 입력 감지
tfInput.addEventListener('input', () => {
  tfConfirm.disabled = !tfInput.value.trim();
});
// 텍스트 파일 만들기 확인 버튼
tfConfirm.addEventListener('click', () => {
  if (!tfInput.value.trim()) {
    alert('텍스트를 입력하세요.');
    return;
  }
  showScreen('textFileNameScreen');
  textFileName.value = '';
  textFileSave.disabled = true;
});
// 텍스트 파일명 입력 시
textFileName.addEventListener('input', () => {
  textFileSave.disabled = !textFileName.value.trim();
});
// 텍스트 파일 저장 버튼
textFileSave.addEventListener('click', () => {
  const name = textFileName.value.trim();
  const ext = tfFileExt.value;
  if (!name) return;
  createTextFile(tfInput.value.trim(), name, ext);
  showScreen('homeScreen');
  tfInput.value = '';
});
// 텍스트 파일 생성 함수
function createTextFile(text, fileName, ext) {
  let content = text;
  let mime = 'text/plain';
  if (ext === 'html') {
    mime = 'text/html';
  }
  const blob = new Blob([content], { type: mime });
  const link = document.createElement('a');
  link.href = URL.createObjectURL(blob);
  link.download = `${fileName}.${ext}`;
  document.body.appendChild(link);
  link.click();
  link.remove();
}
// 취소 버튼들
tfCancel.addEventListener('click', () => showScreen('homeScreen'));
textFileCancel.addEventListener('click', () => showScreen('homeScreen'));
// 푸터 버튼 기능
userLinkBtn.addEventListener('click', () => {
  window.open('https://www.youtube.com/@시각장애인어린이', '_blank');
});
phoneBtn.addEventListener('click', () => {
  window.location.href = 'tel:01094761267';
});
emailBtn.addEventListener('click', () => {
  window.location.href = 'mailto:nknm0812@gmail.com';
});